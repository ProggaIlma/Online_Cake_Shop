package com.example.progga.myjustcake.Shop_cakes;

/**
 * Created by progga on 3/23/18.
 */

public class Shop_cake_list {
    private String txt1,txt2,txt3,txt4;

    public String getTxt1() {
        return txt1;
    }

    public String getTxt2() {
        return txt2;
    }

    public String getTxt3() {
        return txt3;
    }

    public String getTxt4() {
        return txt4;
    }

    public Shop_cake_list(String txt1, String txt2, String txt3, String txt4) {

        this.txt1 = txt1;
        this.txt2 = txt2;
        this.txt3 = txt3;
        this.txt4 = txt4;
    }
}
