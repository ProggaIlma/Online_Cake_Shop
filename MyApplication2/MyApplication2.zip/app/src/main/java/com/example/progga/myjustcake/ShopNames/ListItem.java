package com.example.progga.myjustcake.ShopNames;

/**
 * Created by progga on 3/18/18.
 */

public class ListItem {
    private String text1;
    private String text2;
    private String imageurl;

    public ListItem(String text1,String text2) {
        this.text1 = text1;
        this.text2 = text2;
        //   this.imageurl = imageurl;
    }

    public String getText1() {
        return text1;
    }

    public String getText2() {
        return text2;
    }

    public String getImageurl() {
        return imageurl;
    }
}
