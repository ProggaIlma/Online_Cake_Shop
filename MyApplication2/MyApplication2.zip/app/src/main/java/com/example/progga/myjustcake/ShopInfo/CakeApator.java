package com.example.progga.myjustcake.ShopInfo;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.progga.myjustcake.MyShop.MyShopAdaptor;
import com.example.progga.myjustcake.R;
import com.example.progga.myjustcake.update2;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by progga on 3/20/18.
 */

public class CakeApator extends RecyclerView.Adapter<CakeApator.ViewHolder> {

    private List<CakeList> listItems;
    String k=MyShopAdaptor.t;
    private Context context;
    public  static String cakeno;
    //ImageView imageView;

    public CakeApator(List<CakeList> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    @NonNull
    @Override

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.cake_item,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CakeList listItem=listItems.get(position);
        holder.text1.setText(listItem.getText1());
        holder.text2.setText(listItem.getText2());

        holder.button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cakeno=listItem.getText1();
                Intent intent=new Intent(context,update2.class);
                context.startActivity(intent);

            }
        });

        String name=k+"_"+listItem.getText1()+".jpeg";
        Picasso.with(context).load("http://192.168.10.2/uploads/"+name).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView text1;
        public TextView text2;
        public Button button1;
        ImageView imageView;
        public LinearLayout linearLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            button1=(Button)itemView.findViewById(R.id.details);
            text1=(TextView)itemView.findViewById(R.id.cakename);
            text2=(TextView)itemView.findViewById(R.id.stock);
            imageView=(ImageView)itemView.findViewById(R.id.cakeimage);
            linearLayout=(LinearLayout)itemView.findViewById(R.id.linearlayout);
        }
    }

}