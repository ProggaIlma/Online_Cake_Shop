package com.example.progga.myjustcake.MyShop;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.progga.myjustcake.Constant;
import com.example.progga.myjustcake.Login;
import com.example.progga.myjustcake.Mysingleton;
import com.example.progga.myjustcake.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyShop extends AppCompatActivity {


    final String userno= Login.userno;
    private static final String URL=Constant.get_my_shops;
    private RecyclerView recyclerView;


    private RecyclerView.Adapter adapter;
    public static final String KEY_USERNO="userno";
    private List<MyShopItem> listItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_shop);
        recyclerView = (RecyclerView) findViewById(R.id.recycleview1);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        listItems = new ArrayList<>();
        loadmyshops();
    }
    private void loadmyshops()
    {
        final ProgressDialog progressDialog=new ProgressDialog(this);

        progressDialog.setMessage("Loading Data.........");
        progressDialog.show();
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject= new JSONObject(s);
                    JSONArray array=jsonObject.getJSONArray("myshops");
                    for(int i=0;i<array.length();i++)
                    {
                        JSONObject o=array.getJSONObject(i);

                        MyShopItem item=new MyShopItem(
                                o.getString("shopname"),o.getString("shopno")
                        );
                        listItems.add(item);

                    }
                    adapter=new MyShopAdaptor(listItems,MyShop.this);
                    recyclerView.setAdapter(adapter);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        }){
        protected Map<String,String> getParams(){
        Map<String,String> params = new HashMap<String, String>();
        params.put(KEY_USERNO,userno);
        return params;
    }
        }
        ;
        Mysingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
        //RequestQueue requestQueue= Volley.newRequestQueue(this);
        //requestQueue.add(stringRequest);
    }
}
