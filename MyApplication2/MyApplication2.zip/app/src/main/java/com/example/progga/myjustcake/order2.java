package com.example.progga.myjustcake;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.progga.myjustcake.Shop_cakes.ShopAdapter;
import com.shagi.materialdatepicker.date.DatePickerFragmentDialog;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class order2 extends AppCompatActivity {
    String URL = "http://192.168.1.134/ordercake.php";
    EditText e1, e2, e3;
    String customerno = Login.userno;
    String cakeno = ShopAdapter.cakeno;

    DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    Calendar today = Calendar.getInstance();
    String orderdate = "ss";
    //dateFormat.format(today);
    public static final String KEY_CAKEDESCRIPTION = "cakedescription";
    public static final String KEY_CAKENO = "cakeno";
    public static final String KEY_ORDERDATE = "orderdate";
    public static final String KEY_DELIVARYDATE = "delivarydate";
    public static final String KEY_CUSTOMERNO = "customerno";
    public static final String KEY_TEXT = "text";

    String cakedescription, delivarydate, text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order2);
    }

    public void order(View v) {
        order3();
    }

    public void order3() {
        e1 = (EditText) findViewById(R.id.editText1);
        e2 = (EditText) findViewById(R.id.editText2);
        e3 = (EditText) findViewById(R.id.editText3);
        cakedescription = e1.getText().toString().trim();
        delivarydate = e2.getText().toString().trim();
        text = e3.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equals("Successfully ordered")) {
                    Toast.makeText(order2.this, "Order is taken sucessfully", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(order2.this, "Order is failed", Toast.LENGTH_LONG).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(order2.this, error + "error", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                orderdate = Calendar.getInstance().getTime().toString();

                Map<String, String> params = new HashMap<String, String>();
                params.put(KEY_CAKEDESCRIPTION, cakedescription);
                params.put(KEY_CAKENO, cakeno);
                params.put(KEY_CUSTOMERNO, customerno);
                params.put(KEY_DELIVARYDATE, delivarydate);
                params.put(KEY_ORDERDATE, orderdate);
                params.put(KEY_TEXT, text);
                return params;
            }
        };
        Mysingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }

    public void deliverydate(View view) {
        final DatePickerFragmentDialog dialog =
                DatePickerFragmentDialog.newInstance(new DatePickerFragmentDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePickerFragmentDialog view, int year, int monthOfYear, int dayOfMonth) {
                        Log.e("delivery date", year + " " + monthOfYear + " " + dayOfMonth);
                        String date = year + " " + monthOfYear + " " + dayOfMonth;

                        e2.setText(date);
                    }
                });


        dialog.show(getSupportFragmentManager(), "tag");
    }
}


