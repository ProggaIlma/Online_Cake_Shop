package com.example.progga.myjustcake.Shop_cakes;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.progga.myjustcake.MyShop.MyShopAdaptor;
import com.example.progga.myjustcake.Order;
import com.example.progga.myjustcake.R;
import com.example.progga.myjustcake.ShopNames.MyAdapter;
import com.example.progga.myjustcake.order2;
import com.example.progga.myjustcake.registration;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.List;

/**
 * Created by progga on 3/23/18.
 */

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ViewHolder>{
    private List<Shop_cake_list> listitems;
    private Context context;
    String shopno= MyAdapter.shopno;
    public static String cakeno=null;

    public ShopAdapter(List<Shop_cake_list> listitems, Context context) {
        this.listitems = listitems;
        this.context = context;
    }

    @Override
    public ShopAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.shop_cakes,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ShopAdapter.ViewHolder holder, int position) {
               Shop_cake_list list=listitems.get(position);
               holder.txt1.setText(list.getTxt2());
               holder.txt2.setText(list.getTxt3());
               holder.txt3.setText(list.getTxt4());
               cakeno=list.getTxt1();
               holder.button.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View view) {
                       Intent intent=new Intent(context,order2.class);
                       context.startActivity(intent);

                   }
               });

               String name=shopno+"_"+list.getTxt1();

        Picasso.with(context).load("http://192.168.10.2/uploads/boy.jpeg").into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return listitems.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView txt1,txt2,txt3;
        ImageView imageView;
        LinearLayout linearLayout;
        Button button;
        public ViewHolder(View itemView) {
            super(itemView);
            imageView=(ImageView)itemView.findViewById(R.id.cakeimage);
            txt1=(TextView)itemView.findViewById(R.id.cakename);
            txt2=(TextView)itemView.findViewById(R.id.price);
            txt3=(TextView)itemView.findViewById(R.id.stock);
            button=(Button)itemView.findViewById(R.id.details);

            linearLayout=itemView.findViewById(R.id.linearlayout);
        }
    }
}
