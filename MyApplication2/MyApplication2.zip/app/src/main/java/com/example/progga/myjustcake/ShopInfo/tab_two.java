package com.example.progga.myjustcake.ShopInfo;

/**
 * Created by progga on 3/19/18.
 */

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.progga.myjustcake.MyShop.MyShopAdaptor;
import com.example.progga.myjustcake.Mysingleton;
import com.example.progga.myjustcake.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class tab_two extends Fragment {
  String KEY_SHOPNO="shopno";
  String shopno= MyShopAdaptor.t;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<CakeList> listItems;
    private ImageView imageView;

   // CakeApator adapter;

    String URL="http://192.168.10.2/get_cake_no.php";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab_two, container, false);


        //setContentView(R.layout.activity_main2);
        recyclerView = (RecyclerView)view.findViewById(R.id.recycleview);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        listItems = new ArrayList<>();

        getCakes();

        return view;
    }

    private void getCakes() {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    JSONArray jsonArray=jsonObject.getJSONArray("cakenum");
                    for (int i = 0; i <jsonArray.length(); i++) {
                          JSONObject o=jsonArray.getJSONObject(i);
                          CakeList cakeList=new CakeList(o.getString("cakeno"),o.getString("cakedescription"));
                        Toast.makeText(getActivity(),"hh1",Toast.LENGTH_LONG).show();
                          listItems.add(cakeList);
                    }
                    adapter=new CakeApator(listItems,getActivity());
                    recyclerView.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(),error+"hh",Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params= new HashMap<>();
                params.put(KEY_SHOPNO,shopno);
                return params;
            }
        };
        Mysingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);



    }
}