package com.example.progga.myjustcake;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.progga.myjustcake.ShopNames.navigation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {
    public static String  userno="";
     EditText editTextPassword,editTextEmail;
     Context ctx;
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_EMAIL = "email";
    String url=Constant.login_url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);
        editTextEmail= (EditText) findViewById(R.id.editTextEmail);
    }
    public void loginClick(View view)
    {
        login();

    }


    public void login()
    {

        final String password = editTextPassword.getText().toString().trim();
        final String email = editTextEmail.getText().toString().trim();
        //Toast.makeText(Login.this, "response2", Toast.LENGTH_SHORT).show();
            StringRequest stringRequest=new StringRequest(Request.Method.POST,url,new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                   if (response.trim().equals("error"))

                   {
                        Toast.makeText(Login.this, "Login Failed", Toast.LENGTH_SHORT).show();
                   }
                   else{
              Toast.makeText(Login.this, "Login Success", Toast.LENGTH_SHORT).show();
                       try {
                           JSONObject jsonObject=new JSONObject(response);
                          // Toast.makeText(Login.this, "Login Success1", Toast.LENGTH_SHORT).show();
                           JSONArray array=jsonObject.getJSONArray("userinfo");
                          // Toast.makeText(Login.this, "Login Success2", Toast.LENGTH_SHORT).show();
                           for(int i=0;i<array.length();i++)
                           {
                               //Toast.makeText(Login.this, "Login Success3", Toast.LENGTH_SHORT).show();
                               JSONObject o=array.getJSONObject(i);
                               //Toast.makeText(Login.this, "Login Success4", Toast.LENGTH_SHORT).show();
                               userno=o.getString("userno");
                               //Toast.makeText(Login.this,userno,Toast.LENGTH_LONG).show();
                           }
                           Toast.makeText(Login.this, "Login Success2", Toast.LENGTH_SHORT).show();
                       } catch (JSONException e) {
                           e.printStackTrace();
                       }
                       Intent intent=new Intent(Login.this,navigation.class);
                       startActivity(intent);
                       finish();

                   }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(Login.this, "error"+error.toString(), Toast.LENGTH_SHORT).show();
                }
            })

            {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params= new HashMap<>();
                    params.put(KEY_EMAIL,email);
                    params.put(KEY_PASSWORD,password);
                    return params;
                }
            };

        Mysingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
        //RequestQueue requestQueue = Volley.newRequestQueue(Login.this);
        //requestQueue.add(stringRequest);
}

    /**
     * Created by progga on 3/16/18.
     */



    /**
     * Created by progga on 3/16/18.
     */

}
