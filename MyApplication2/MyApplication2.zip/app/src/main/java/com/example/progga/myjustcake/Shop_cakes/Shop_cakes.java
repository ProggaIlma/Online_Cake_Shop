package com.example.progga.myjustcake.Shop_cakes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.progga.myjustcake.MyShop.MyShopAdaptor;
import com.example.progga.myjustcake.Mysingleton;
import com.example.progga.myjustcake.R;
import com.example.progga.myjustcake.ShopInfo.CakeApator;
import com.example.progga.myjustcake.ShopNames.MyAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Shop_cakes extends AppCompatActivity {
    String shopno= MyAdapter.shopno;
    public static final String KEY_SHOPNO="shopno";
    String URL="http://192.168.1.134/get_cake_no.php";
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    List<Shop_cake_list> listitems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        recyclerView = (RecyclerView) findViewById(R.id.recycleview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        listitems = new ArrayList<>();
        getcakes();
    }
    public void getcakes()
    {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    Toast.makeText(getApplicationContext(),"error1",Toast.LENGTH_LONG).show();
                    JSONArray jsonArray=jsonObject.getJSONArray("cakenum");
                    for(int i=0;i<jsonArray.length();i++)
                    {
                        JSONObject o=jsonArray.getJSONObject(i);
                        Shop_cake_list shopCakeList=new Shop_cake_list(
                                o.getString("cakeno"),o.getString("cakedescription")
                                ,o.getString("cakeprice"),o.getString("stock")
                        );
                        Toast.makeText(getApplicationContext(),"error2",Toast.LENGTH_LONG).show();
                        listitems.add(shopCakeList);

                        Toast.makeText(getApplicationContext(),"error3",Toast.LENGTH_LONG).show();
                    }
                    adapter=new ShopAdapter(listitems,Shop_cakes.this);
                    recyclerView.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error+"error",Toast.LENGTH_LONG).show();
            }
        }){


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<String, String>();
                params.put(KEY_SHOPNO,shopno);
                return params;
            }
        };
        Mysingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }
}
