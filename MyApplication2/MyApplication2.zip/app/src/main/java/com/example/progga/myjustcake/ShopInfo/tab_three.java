package com.example.progga.myjustcake.ShopInfo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.progga.myjustcake.MyShop.MyShopAdaptor;
import com.example.progga.myjustcake.Mysingleton;
import com.example.progga.myjustcake.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static android.app.Activity.RESULT_OK;

/**
 * Created by progga on 3/19/18.
 */

public class tab_three extends Fragment implements View.OnClickListener {
    String shopno = MyShopAdaptor.t;
    String SHOPNO_KEY = "shopno", usernum = "userno";
    String cakeno = "jj";
    public static final int IMG = 1;
    Button button1, button2;
    Bitmap bitmap;
    ImageView imageView;
    EditText editText1;
   // String URL = "http://192.168.1.129/upload.php";
    String URL = "http://192.168.1.129/cakeshop/com/insert_cake.php";
    String URL2 = "http://192.168.1.134/new_cake.php";
    public static final String name = "name";
    public static final String image = "image";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab_three, container, false);
        imageView = (ImageView) view.findViewById(R.id.image);
        button1 = (Button) view.findViewById(R.id.button1);
        button2 = (Button) view.findViewById(R.id.button2);
        editText1 = (EditText) view.findViewById(R.id.editText1);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button1:
                selectImage();

                break;
            case R.id.button2: {
                //cakeno();
                uploadimage();
                break;
            }
            default:
                break;
        }
    }


    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, IMG);

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == IMG && resultCode == RESULT_OK && data != null) {
            Uri path = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), path);
                imageView.setImageBitmap(bitmap);
                imageView.setVisibility(View.VISIBLE);
                editText1.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void cakeno() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL2, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("userifo");
                    Toast.makeText(getActivity(), "error1", Toast.LENGTH_SHORT).show();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject o = jsonArray.getJSONObject(i);
                        cakeno = o.getString("MAX(cakeno)");
                        Toast.makeText(getActivity(), cakeno, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "error" + error.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        Mysingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
    }

    private void uploadimage() {
        final String m = editText1.getText().toString().trim();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e("Response", response);
                        // JSONObject jsonObject=new JSONObject(response);
                        // String Response=jsonObject.getString("response");
                       /* if (response.equals("success"))
                            //Toast.makeText(getActivity(), "Response", Toast.LENGTH_LONG).show();
                        //Toast.makeText(getActivity(),imagetostring(bitmap),Toast.LENGTH_LONG).show();
                        else if (response.equals("not success"))
                            Toast.makeText(getActivity(), "Arman", Toast.LENGTH_LONG).show();*/
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), error + "jjj", Toast.LENGTH_LONG).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                String imagee = imagetostring(bitmap);
                params.put(name, m);
                params.put(SHOPNO_KEY, shopno);
                //params.put(usernum,shopno);
                //params.put(image, imagee);
                params.put("cakedescription", "desc");
                params.put("cakeprice", 100+"");
                params.put("stock", ""+100);
                //params.put("shopno", ""+100);
                params.put(image, imagee);
                // Toast.makeText(getActivity(),imagetostring(bitmap),Toast.LENGTH_LONG).show();
                return params;
            }
        };
        Mysingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);


    }

    private String imagetostring(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 30, byteArrayOutputStream);
        byte[] imgBytes = byteArrayOutputStream.toByteArray();
        String code = Base64.encodeToString(imgBytes, Base64.DEFAULT);
        return code;


    }


}