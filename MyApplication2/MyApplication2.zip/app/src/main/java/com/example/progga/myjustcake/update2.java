package com.example.progga.myjustcake;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.progga.myjustcake.ShopInfo.CakeApator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class update2 extends AppCompatActivity {
    String URL="http://192.168.1.134/get_cake_info.php";
    String URL2="";
    EditText e1,e2,e3;
    String cakeno= CakeApator.cakeno;
    public static final String KEY_CAKENO="cakeno";
    public static final String KEY_CAKEDESCRIPTION="cakedescription";
    public static final String KEY_PRICE="price";
    public static final String KEY_STOCK="stock";
    String cakedescription,cakeprice,stock;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update2);
        e1=(EditText)findViewById(R.id.editText1);
        e2=(EditText)findViewById(R.id.editText2);
        e3=(EditText)findViewById(R.id.editText3);
         show1();
    }
    public void Update1()
    {

    }
    public void update()
    {


        final String cakedescription=e1.getText().toString().trim();
        final String price=e2.getText().toString().trim();
        final String stock=e3.getText().toString().trim();
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL2, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<String, String>();
                params.put(KEY_CAKEDESCRIPTION,cakedescription);
                params.put(KEY_PRICE,price);
                params.put(KEY_STOCK,stock);
                return params;
            }
        };
    }
    public void show1()
    {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    Toast.makeText(update2.this,"error0",Toast.LENGTH_LONG).show();
                    JSONArray jsonArray=jsonObject.getJSONArray("cakenum");
                    Toast.makeText(update2.this,"error1",Toast.LENGTH_LONG).show();
                    for(int i=0;i<jsonArray.length();i++)
                    {
                        JSONObject o=jsonArray.getJSONObject(i);
                        cakedescription=o.getString("cakedescription");
                        cakeprice=o.getString("cakeprice");
                        stock=o.getString("stock");
                        Toast.makeText(update2.this,"error2",Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Toast.makeText(update2.this,"error3",Toast.LENGTH_LONG).show();
                e1.setText(cakedescription);
                e2.setText(cakeprice);
                e3.setText(stock);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(update2.this,error+"error",Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<String, String>();
                params.put(KEY_CAKENO,cakeno);
                return params;
            }
        };
        Mysingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
    }
}
