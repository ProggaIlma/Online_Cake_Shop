package com.example.progga.myjustcake;

/**
 * Created by progga on 2/27/18.
 */

public class Constant {
    public static final String SERVER_URL = "http://192.168.1.134/";
    public static final String a = "";
    public static final String login_url2 = SERVER_URL + "cakeshop/com/login_verification.php";
    public static final String login_url = SERVER_URL + "login1.php";
    public static final String reg_url = SERVER_URL + "cakeshop/com/registration.php";
    public static final String reg_url2 = SERVER_URL + "registration.php";
    public static final String cakeshop = SERVER_URL + "cakeshops.php";
    public static final String createshop_url = SERVER_URL + "createshop.php";
    public static final String get_my_shops = SERVER_URL + "get_my_shops.php";
    public static final String imageurl= SERVER_URL + "get_my_shops.php";
    public static final String get_my_shops_info ="http://192.168.10.2/get_my_shop_info.php";
    public static final String upload ="http://192.168.10.2/upload.php";
}
