package com.example.progga.myjustcake;

/**
 * Created by progga on 3/9/18.
 */


        import android.content.Context;

        import com.android.volley.Request;
        import com.android.volley.RequestQueue;
        import com.android.volley.toolbox.Volley;

/**
 * Created by progga on 3/7/18.
 */

public class Mysingleton {
    private static Mysingleton mysingleton;
    private RequestQueue requestQueue;
    private static Context mctx;
    private Mysingleton(Context context)
    {
        mctx=context;
        requestQueue=getRequestQueue();
    }
    public RequestQueue getRequestQueue()
    {
        if(requestQueue==null)
        {
            requestQueue= Volley.newRequestQueue(mctx.getApplicationContext());
        }
        return requestQueue;
    }
    public static synchronized Mysingleton getInstance(Context context)
    {
        if(mysingleton==null)
        {
            mysingleton=new Mysingleton(context);
        }
        return mysingleton;
    }

    public<T> void addToRequestQueue(Request<T> request)
    {
        requestQueue.add(request);
    }
}
