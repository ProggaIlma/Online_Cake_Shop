<?php
#MySQL Database name:
define('DB_NAME', 'main_cakeshop');

#MySQL Database User Name:
define('DB_USER', 'root');

#MySQL Database Password:
define('DB_PASSWORD', 'anything');

#MySQL Hostname:
define('DB_HOST', 'localhost');



#Table Prefix:
define('PREFIX','eis');

#Session Timeout Time:
define('SESSION_TIMEOUT',360000);

#Major version:
define('VERSION','1.0');


?>
<?php
#Base Path :
#Please Do not change this absolute path.
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

?>
